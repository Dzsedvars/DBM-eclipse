DBM:RegisterMapSize("HallsofReflection", 1, 879.02001954, 586.01953124) -- Halls of Reflection
