DBM:RegisterMapSize("UtgardePinnacle",
	1, 548.936019897, 365.957015991,	-- Lower Pinnacle
	2, 756.17994308428, 504.119003295	-- Upper Pinnacle
)
