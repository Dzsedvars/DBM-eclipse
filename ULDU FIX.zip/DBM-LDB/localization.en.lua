DBM_LDB_TOOLTIP_HELP1	= "Left-click to open DBM"
DBM_LDB_TOOLTIP_HELP2	= "Right-click to open config menu"

DBM_LDB_LOAD_MODS		= "Load boss mods"

DBM_LDB_CAT_WOTLK		= "Wrath of the Lich King"
DBM_LDB_CAT_BC			= "The Burning Crusade"
DBM_LDB_CAT_CLASSIC 	= "WoW Classic Bosses"
DBM_LDB_CAT_OTHER		= "Other Boss Mods"

DBM_LDB_CAT_GENERAL		= "General"
DBM_LDB_ENABLE_BOSS_MOD	= "Enable boss mod"
DBM_LDB_ANNOUN_BOSS_MOD = "Announce to raid"
