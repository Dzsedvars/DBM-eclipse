if GetLocale() ~= 'koKR' then return end
DBM_LDB_TOOLTIP_HELP1	= "<왼쪽-클릭> DBM 불러오기"
DBM_LDB_TOOLTIP_HELP2	= "<오른쪽-클릭> 설정 모드 불러오기"

DBM_LDB_LOAD_MODS		= "보스 모드 불러오기"

DBM_LDB_CAT_WOTLK		= "리치왕의 분노"
DBM_LDB_CAT_BC			= "불타는 성전"
DBM_LDB_CAT_CLASSIC 		= "오리지널"
DBM_LDB_CAT_OTHER		= "기타 보스 모드"

DBM_LDB_CAT_GENERAL		= "일반"
DBM_LDB_ENABLE_BOSS_MOD	= "보스 모드 사용"
DBM_LDB_ANNOUN_BOSS_MOD = "공격대 경보로 알리기"
