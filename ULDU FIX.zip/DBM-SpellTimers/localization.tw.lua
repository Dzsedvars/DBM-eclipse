-- yleaf(yaroot@gmail.com)/Juha
if GetLocale() ~= "zhTW" then return end
local L = DBM_SpellsUsed_Translations

L.TabCategory_SpellsUsed	= "冷卻助手"
L.AreaGeneral 			= "一般設定"
L.Enable 			= "開啟冷卻計時"
L.Show_LocalMessage 		= "顯示本地提示"
L.Enable_inRaid			= "僅顯示團隊成員的冷卻訊息"
L.Enable_inBattleground		= "戰場中依然啟用"
L.Enable_Portals		= "顯示時間"
L.Reset				= "重置設定"
L.Local_CastMessage 		= "檢測到施法: %s"
L.AreaAuras 			= "技能設定"
L.SpellID 			= "法術編號"
L.BarText 			= "計時條文字(預設: %spell: %player)"
L.Cooldown 			= "冷卻時間"
L.Error_FillUp			= "請填寫完整"
